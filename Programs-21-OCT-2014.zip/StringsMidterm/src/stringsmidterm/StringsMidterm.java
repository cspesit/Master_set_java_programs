/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package stringsmidterm;

/**
 *
 * @author vijay.dontharaju
 */
public class StringsMidterm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String var1 = "Jack";
        String var2 = "Jack in the box";
        
        if(var2.contains(var1))
        {
            System.out.println(var1 + " is a substring of " + var2);
        }
        
    }
    
}
